Le Parfum Simplifié: photography pack (36 photographs, 2400px)

These photographs are already built into the theme zip; this pack is a copy you can
keep, upload to Shopify Files, or use elsewhere (social posts, emails, Discord).

Licence: Pexels licence (https://www.pexels.com/license/). Free for commercial use,
no attribution required. Do not sell the photos unaltered, and do not imply that
people shown endorse Le Parfum Simplifié.

Sources (file name, original Pexels page):
studio-overhead.jpg  https://www.pexels.com/photo/8450466/
bench-still-life.jpg  https://www.pexels.com/photo/8450383/
pipette-hand.jpg  https://www.pexels.com/photo/8450357/
tagged-bottles.jpg  https://www.pexels.com/photo/8450393/
vials-botanicals.jpg  https://www.pexels.com/photo/8450512/
raw-materials.jpg  https://www.pexels.com/photo/8450519/
mortar-petals.jpg  https://www.pexels.com/photo/8450505/
notebook-formula.jpg  https://www.pexels.com/photo/8450476/
notebook-writing.jpg  https://www.pexels.com/photo/8450384/
beaker-pour.jpg  https://www.pexels.com/photo/8450352/
scale-weighing.jpg  https://www.pexels.com/photo/8450351/
funnel-bottle.jpg  https://www.pexels.com/photo/8450475/
overhead-bottles.jpg  https://www.pexels.com/photo/8450397/
tags-twine.jpg  https://www.pexels.com/photo/8450471/
label-bottle.jpg  https://www.pexels.com/photo/8450511/
marble-vials.jpg  https://www.pexels.com/photo/8450508/
study-magnifier.jpg  https://www.pexels.com/photo/8450472/
tagged-row.jpg  https://www.pexels.com/photo/8450361/
pipette-vials.jpg  https://www.pexels.com/photo/8450510/
skin-test.jpg  https://www.pexels.com/photo/8450513/
workspace-tags.jpg  https://www.pexels.com/photo/8450469/
amber-tag.jpg  https://www.pexels.com/photo/8450346/
gloves-bottle.jpg  https://www.pexels.com/photo/8450388/
spices-white.jpg  https://www.pexels.com/photo/5475170/
spices-bowls.jpg  https://www.pexels.com/photo/678414/
rose-buds.jpg  https://www.pexels.com/photo/6823259/
amber-linen.jpg  https://www.pexels.com/photo/7795755/
amber-set-linen.jpg  https://www.pexels.com/photo/7795764/
amber-mirror.jpg  https://www.pexels.com/photo/7796494/
oil-bottle-flowers.jpg  https://www.pexels.com/photo/7796498/
sphere-bottle.jpg  https://www.pexels.com/photo/7796811/
dropper-ceramic.jpg  https://www.pexels.com/photo/7797736/
dropper-dried-flowers.jpg  https://www.pexels.com/photo/7797748/
tray-flatlay.jpg  https://www.pexels.com/photo/7797752/
workbench-jars.jpg  https://www.pexels.com/photo/8450521/
lavender-vial.jpg  https://www.pexels.com/photo/932577/
